#!/bin/bash
git clean -f -d
git checkout -- ./
git pull
